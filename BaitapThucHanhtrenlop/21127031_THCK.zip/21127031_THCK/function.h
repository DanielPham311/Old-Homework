//21127031_Phạm Quốc Duy

#define MAX 100

typedef struct Diem
{
    float Toan;
    float Ly;
    float Hoa;
    float Van;
    float Tin;
};

typedef struct HocSinh
{
    Diem array[6];
    char MaHS;
    char HoDem[MAX];
    char Ten[MAX];
    char NgaySinh[MAX];
    char GioiTinh;
    char DiaChi[MAX];
}HS;

void DocThongTin(HS &a);

void DocDiem(HS &a);





