//21127031_Phạm Quốc Duy

#include <iostream>
#include "function.h"
#include <string.h>

using namespace std;

int main()
{
    HS a;
    
}